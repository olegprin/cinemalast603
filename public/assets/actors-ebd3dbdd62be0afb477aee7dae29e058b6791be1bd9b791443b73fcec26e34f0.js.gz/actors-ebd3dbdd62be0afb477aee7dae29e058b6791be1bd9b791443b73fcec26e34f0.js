var ass="Olesa";

alert(ass+788);
