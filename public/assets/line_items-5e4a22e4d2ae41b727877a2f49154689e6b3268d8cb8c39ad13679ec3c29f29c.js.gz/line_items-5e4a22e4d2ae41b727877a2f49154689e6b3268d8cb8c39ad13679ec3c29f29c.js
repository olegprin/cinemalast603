(function() {
  alert("line");

}).call(this);
